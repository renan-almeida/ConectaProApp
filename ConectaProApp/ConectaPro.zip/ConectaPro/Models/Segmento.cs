﻿using ConectaProApp.Models.Enuns;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConectaProApp.Models
{
    public class Segmento
    {
        public int IdSegmento { get; set; } 
        public string DescSegmento { get; set; }
    }
}
