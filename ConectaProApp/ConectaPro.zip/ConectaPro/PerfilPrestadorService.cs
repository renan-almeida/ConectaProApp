﻿using ConectaProApp.Models;
using ConectaProApp.Models.Enuns;
using System.Net.Http.Headers;
using System.Diagnostics;
using Newtonsoft.Json;
using System.Globalization;
using ConectaProApp.Converters;

namespace ConectaProApp.Services.Prestador
{
    public class PerfilPrestadorService
    {
        private readonly Request _request;
        private const string apiUrlBase = "https://conectapro-api.azurewebsites.net";
        private static readonly HttpClient client = new HttpClient();
        private readonly ApiService _apiService;

        public PerfilPrestadorService()
        {
            _request = new Request();
            _apiService = new ApiService();
        }

        public async Task<List<ServicoDTO>> BuscarPropostasPrestadorAsync(int idPrestador)
        {
            try
            {
               
                var token = await SecureStorage.GetAsync("token");
                Debug.WriteLine($"🔵 Token obtido: {token}");
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                var endpoint = $"/perfil/prestador/{idPrestador}/propostas-recebidas";
                var response = await client.GetAsync(apiUrlBase + endpoint);
                Debug.WriteLine("resposta: " + response);

                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    Debug.WriteLine("Json: " + json);

                    var propostas = JsonConvert.DeserializeObject<List<ServicoDTO>>(json, new JsonSerializerSettings
                    {
                        Converters = new List<JsonConverter>
                        {new DateTimeFromStringNewtonsoftConverter("dd/MM/yyyy - HH:mm"),
                         new DateTimeNullableFromStringNewtonsoftConverter("dd/MM/yyyy - HH:mm"),
                         new DateOnlyFromStringNewtonsoftConverter("dd/MM/yyyy"),
                         new DecimalFromStringNewtonsoftConverter(),
                         new SafeStringEnumConverter<FormaPagtoEnum>(),       // seu enum de pagamento
                         new SafeStringEnumConverter<NvlUrgenciaEnum>(),       // seu enum de urgência
                         new SafeStringEnumConverter<TipoSegmentoEnum>(),     // (se tiver outros enums, pode adicionar aqui também)
                         new SafeStringEnumConverter<StatusServicoEnum>()
                        },
                        Culture = new CultureInfo("pt-BR"),

                         Error = (sender, args) =>
                         {
                             args.ErrorContext.Handled = true;
                         }
                    });
                    Debug.WriteLine("propostas: " + propostas);

                    var filtrados = propostas.Where(p =>
                       p.SituacaoServico != StatusServicoEnum.ORCAMENTO &&
                       p.SituacaoServico != StatusServicoEnum.FINALIZADO &&
                       p.SituacaoServico != StatusServicoEnum.Cancelado &&
                       p.SituacaoServico != StatusServicoEnum.RECUSADO
                   ).ToList();

                    return propostas;
                }

                throw new Exception("Erro ao buscar propostas: resposta não foi bem-sucedida.");
            }
            catch (Exception ex)
            {
                throw new Exception($"Erro ao buscar propostas: {ex.Message}", ex);
            }
        }
    


     public async Task<List<ServicoDTO>> BuscarCandidaturasPrestadorAsync(int idPrestador)
        {
            try
            {

                var token = await SecureStorage.GetAsync("token");
                Debug.WriteLine($"🔵 Token obtido: {token}");
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                var endpoint = $"/perfil/prestador/{idPrestador}/candidaturas";
                var response = await client.GetAsync(apiUrlBase + endpoint);
                Debug.WriteLine("resposta: " + response);

                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    Debug.WriteLine("Json: " + json);

                    var propostas = JsonConvert.DeserializeObject<List<ServicoDTO>>(json, new JsonSerializerSettings
                    {
                        Converters = new List<JsonConverter>
                        {new DateTimeFromStringNewtonsoftConverter("dd/MM/yyyy - HH:mm"),
                         new DateTimeNullableFromStringNewtonsoftConverter("dd/MM/yyyy - HH:mm"),
                         new DateOnlyFromStringNewtonsoftConverter("dd/MM/yyyy"),
                         new DecimalFromStringNewtonsoftConverter(),
                         new SafeStringEnumConverter<FormaPagtoEnum>(),       // seu enum de pagamento
                         new SafeStringEnumConverter<NvlUrgenciaEnum>(),       // seu enum de urgência
                         new SafeStringEnumConverter<TipoSegmentoEnum>(),     // (se tiver outros enums, pode adicionar aqui também)
                         new SafeStringEnumConverter<StatusServicoEnum>()
                        },
                        Culture = new CultureInfo("pt-BR"),

                        Error = (sender, args) =>
                        {
                            args.ErrorContext.Handled = true;
                        }
                    });
                    Debug.WriteLine("propostas: " + propostas);

                    var filtrados = propostas.Where(p =>
                         p.SituacaoServico == StatusServicoEnum.PENDENTE_INICIO ||
                         p.SituacaoServico == StatusServicoEnum.RECUSADO
                     ).ToList();

                    return propostas;
                }

                throw new Exception("Erro ao buscar propostas: resposta não foi bem-sucedida.");
            }
            catch (Exception ex)
            {
                throw new Exception($"Erro ao buscar propostas: {ex.Message}", ex);
            }
        }

        public async Task<List<ServicoDTO>> BuscarServicosPrestadorAsync(int idPrestador)
        {
            try
            {
                var token = await SecureStorage.GetAsync("token");
                Debug.WriteLine($"🔵 Token obtido: {token}");
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                var endpoint = $"/perfil/prestador/{idPrestador}/servicos-prestados";
                var response = await client.GetAsync(apiUrlBase + endpoint);
                Debug.WriteLine($"🔵 Resposta HTTP: {response}");

                if (!response.IsSuccessStatusCode)
                    throw new Exception($"HTTP {response.StatusCode}: {response.ReasonPhrase}");

                var json = await response.Content.ReadAsStringAsync();
                Debug.WriteLine($"🔵 Json recebido: {json}");

                var propostas = JsonConvert.DeserializeObject<List<ServicoDTO>>(json, new JsonSerializerSettings
                {
                    Converters = new List<JsonConverter>
            {
                new DateTimeFromStringNewtonsoftConverter("dd/MM/yyyy - HH:mm"),
                new DateTimeNullableFromStringNewtonsoftConverter("dd/MM/yyyy - HH:mm"),
                new DateOnlyFromStringNewtonsoftConverter("dd/MM/yyyy"),
                new DecimalFromStringNewtonsoftConverter(),
                new SafeStringEnumConverter<FormaPagtoEnum>(),
                new SafeStringEnumConverter<NvlUrgenciaEnum>(),
                new SafeStringEnumConverter<TipoSegmentoEnum>(),
                new SafeStringEnumConverter<StatusServicoEnum>()
            },
                    Culture = new CultureInfo("pt-BR"),
                    Error = (sender, args) => args.ErrorContext.Handled = true
                });

                Debug.WriteLine($"🔵 Total de serviços desserializados: {propostas?.Count ?? 0}");

                var filtrados = propostas?.Where(p =>
                    p.SituacaoServico == StatusServicoEnum.FINALIZADO
                ).ToList() ?? new List<ServicoDTO>();

                Debug.WriteLine($"🔵 Total filtrado: {filtrados.Count}");

                return filtrados;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"❌ ERRO BuscarServicosPrestadorAsync: {ex}");
                throw new Exception($"Erro ao buscar serviços prestador: {ex.Message}", ex);
            }
        }





    }
}
