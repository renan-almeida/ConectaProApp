using CommunityToolkit.Maui.Views;

namespace ConectaProApp.View.PopUp;

public partial class PropostaSucesso : Popup
{
	public PropostaSucesso()
	{
		InitializeComponent();
	}
}