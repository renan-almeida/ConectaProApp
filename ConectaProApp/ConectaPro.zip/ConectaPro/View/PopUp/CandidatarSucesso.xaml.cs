using CommunityToolkit.Maui.Views;

namespace ConectaProApp.View.PopUp;

public partial class TestePopup : Popup
{
	public TestePopup()
	{
		InitializeComponent();
	}
}