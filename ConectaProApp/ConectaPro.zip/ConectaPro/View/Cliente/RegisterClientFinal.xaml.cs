namespace ConectaProApp.View.Cliente;

public partial class RegisterClientFinal : ContentPage
{
	public RegisterClientFinal()
	{
		InitializeComponent();
	}
}