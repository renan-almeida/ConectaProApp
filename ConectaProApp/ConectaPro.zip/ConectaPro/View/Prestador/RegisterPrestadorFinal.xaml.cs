namespace ConectaProApp.View.Prestador;

public partial class RegisterPrestadorFinal : ContentPage
{
	public RegisterPrestadorFinal()
	{
		InitializeComponent();
	}
}